<!DOCTYPE html>
<html>
    <head>
        <title>MVC Barang</title>
        <link rell="stylesheet" href="style.css">
    </head>
     <style>
        body {
            margin: 0;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-image: url(carlos.jpg);
        }

        nav a {
            color: white;
            text-decoration: none;
            margin-left: 20px;
            font-weight: 500;
            padding: 10px 16px;
            border-radius: 6px;
            transition: background-color 0.3s ease, color 0.3s ease;
        }


        /* MAIN */
        main {
            padding: 40px;
        }

        h2 {
            color:rgb(37, 28, 24);
        }

        h1{
          
           color:rgb(44, 43, 43); 
        }

        p {
            color:rgb(0, 0, 0);
        }

    
        
    </style>
</head>
<body>
</body>
    <body>
       <center><h1> Sistem Informasi</h1> </center>
        <?php include("menu.php"); ?>
 
      
