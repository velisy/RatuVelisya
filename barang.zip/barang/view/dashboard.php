<?php include("header.php"); ?>

<center> <h2>Selamat Datang di Dashboard</h2> </center>
<center> <p>Silakan pilih menu di atas untuk mengelola data apa saja yang kamu mau.</p> </center>

<?php include("footer.php"); ?>