<?php
//$page = $_GET['page'] ?? 'dashboard';
$page = isset($_GET['page']) ? $_GET['page'] : 'dashboard';

switch ($page) {
    case 'dashboard':
        include 'view/dashboard.php';
        break;
    case 'barang':
        include 'controller/BarangController.php';
        break;
    default:
        echo "Halaman tidak ditemukan";
}
?>